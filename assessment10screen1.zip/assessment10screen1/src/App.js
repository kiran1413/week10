import logo from './logo.svg';
import './App.css';
import Loadingscreen from './Loadingscreen.js';

function App() {
  return (
    <div className='bgcol'>
      <div className='text'>
        <div className="App">
          <header className="App-header">
            <img src={logo} className="App-logo" alt="logo" />
          </header>
        </div>
        <img src="Loading.png" /><br />
        <img src="screen.png" /><br />
        <img src="reactjs.png" /><br />

      </div>
      <Loadingscreen />
    </div>
  );
}

export default App;