import './Loadingscreen.css';
import React, { useEffect, useState } from "react";
function Loadingscreen() {
    return (
                        <div className='cen'>
                        <div className="spinner">
                            <center><span>Loading...</span></center>
                            <div className="half-spinner"></div>
                        </div>
                        </div>
    );
}
 
export default Loadingscreen;